'use client';

export default function Home() {
  const items = Array.from({ length: 18 }, (_, i) => ({
    id: i + 1,
    title: `Model ${i + 1}`,
    author: `Author ${i + 1}`,
    price: `SAT ${(i + 1) * 10}`,
    link: `/model/${i + 1}`,
  }));

  return (
    <>
      {/* Hero Section */}
      <div className="bg-[#111] text-white py-16 text-center">
        <h1 className="text-4xl font-bold mb-4">Discover Stunning 3D Models</h1>
        <p className="text-lg text-gray-400 mb-8">
          Explore, buy, and showcase high-quality 3D models from talented creators.
        </p>
        <button className="bg-blue-600 px-6 py-3 rounded-md text-white font-semibold hover:bg-blue-700 transition">
          Explore Models
        </button>
      </div>

      {/* Featured Models Section */}
      <div className="my-16 w-4/5 mx-auto">
        <h2 className="text-2xl font-bold mb-6">Featured Models</h2>
        <div className="grid grid-cols-3 gap-4">
          {items.slice(0, 3).map((item) => (
            <a
              key={item.id}
              href={item.link}
              className="border border-[#333] p-4 rounded-md shadow hover:shadow-lg transition"
            >
              <div className="bg-[#333] h-48 mb-4 flex items-center justify-center rounded-lg">
                <span className="text-gray-500">3D Model Placeholder</span>
              </div>
              <h2 className="text-lg font-bold">{item.title}</h2>
              <p className="text-sm text-gray-600">{item.author}</p>
              <p className="text-sm font-semibold">{item.price}</p>
            </a>
          ))}
        </div>
      </div>

      {/* All Models Grid */}
      <div className="grid grid-cols-3 gap-4 p-4 my-16 w-4/5 mx-auto">
        {items.map((item) => (
          <a
            key={item.id}
            href={item.link}
            className="border border-[#333] p-4 rounded-md shadow hover:shadow-lg transition"
          >
            <div className="bg-[#333] h-32 mb-4 flex items-center justify-center rounded-lg">
              <span className="text-gray-500">3D Model Placeholder</span>
            </div>
            <h2 className="text-lg font-bold">{item.title}</h2>
            <p className="text-sm text-gray-600">{item.author}</p>
            <p className="text-sm font-semibold">{item.price}</p>
          </a>
        ))}
      </div>
    </>
  );
}
